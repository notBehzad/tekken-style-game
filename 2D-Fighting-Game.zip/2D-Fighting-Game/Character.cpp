#include<iostream>
#include<SFML/Graphics.hpp>
#include<string>
#include "Character.h"
#include<iomanip>
#include<fstream>
using namespace std;
using namespace sf;

//Berserk Special ability: double the attack for 3 seconds, cooldown time 5s
//Shaman : 20hp+, cooldown 6s
//warrior : enemy defense doesnt work for next 4s, cooldown 5s
//bob : -40hp, cooldown 10s
//devilJin : freeze enemy for 3s, cooldown 6s

Character::Character(string n) : name(n), x(0), y(0) {
	currentMove = NULL;
	frame = 0;
	damageGot = 0;
	health = 100;
	freeze = false;
}

string Character::getName() { return name; }
float& Character::getHealth() { return health; }
void Character::setSide(bool s) { side = s; }
bool Character::getSide() { return side; }
int Character::getX() { return x; }
int Character::getY() { return y; }
void Character::resetFrame() { frame = 0; }
float Character::getDefense() { return defense; }


Berserk::Berserk() : Character("Berserk") {
	getTexture().loadFromFile("assets/characters/0/pic.png");
	getSprite().setTexture(getTexture());
	setDisplayPosition();
	getSprite().setScale(1.5f, 1.5f);
	setValuesFromConfig();
}
void Berserk::setDisplayPosition() {
	getSprite().setPosition(80, 260);
}

Shaman::Shaman() : Character("Shaman") {
	getTexture().loadFromFile("assets/characters/1/pic.png");
	getSprite().setTexture(getTexture());
	setDisplayPosition();
	getSprite().setScale(1.5f, 1.5f);
	setValuesFromConfig();
}
void Shaman::setDisplayPosition() {
	getSprite().setPosition(210, 260);
}
Warrior::Warrior() : Character("Warrior") {
	getTexture().loadFromFile("assets/characters/2/pic.png");
	getSprite().setTexture(getTexture());
	setDisplayPosition();
	getSprite().setScale(1.5f, 1.5f);
	setValuesFromConfig();
}
void Warrior::setDisplayPosition() {
	getSprite().setPosition(340, 260);
}
Bob::Bob() : Character("Bob") {
	getTexture().loadFromFile("assets/characters/3/pic.png");
	getSprite().setTexture(getTexture());
	setDisplayPosition();
	getSprite().setScale(1.8f, 1.8f);
	setValuesFromConfig();
}
void Bob::setDisplayPosition() {
	getSprite().setPosition(450, 230);
}
DevilJin::DevilJin() : Character("DevilJin") {
	getTexture().loadFromFile("assets/characters/4/pic.png");
	getSprite().setTexture(getTexture());
	setDisplayPosition();
	getSprite().setScale(1.8f, 1.8f);
	setValuesFromConfig();
}
void DevilJin::setDisplayPosition() {
	getSprite().setPosition(590, 230);
}
void Berserk::attackTarget(Character&) {
	cout << "wojef";
}
void Berserk::useSpecialAbility(Character& enemy) {
	attackVal *= 2;
}
void Shaman::attackTarget(Character&) {
	cout << "wojef";
}
void Shaman::useSpecialAbility(Character& enemy) {
	if(health<80) health += 20;
}
void Warrior::attackTarget(Character&) {
	cout << "wojef";
}
void Warrior::useSpecialAbility(Character& enemy) {
	attackVal += enemy.getDefense();
}
void Bob::attackTarget(Character&) {
	cout << "wojef";
}
void Bob::useSpecialAbility(Character& enemy) {
	enemy.getHealth() -= 40;
}
void DevilJin::attackTarget(Character&) {
	cout << "wojef";
}
void DevilJin::useSpecialAbility(Character& enemy) {
	enemy.freeze = true;
}

Texture& Character::getTexture() { return texture; }
Sprite& Character::getSprite() { return player; }

void Character::setValuesFromConfig() {
	ifstream input("config.txt");
	string playerName;
	while (input >> playerName >> specialAbilityCoolDown >> attackVal >> defense>>specialAbilityDuration) {
		if (playerName == name) break;
	}
	input.close();
}

Sprite* Character::idle(Character& enemy) {
		player.setTexture(moveIdle[0]);
		return &player;
}
Sprite* Character::dead(Character& enemy) {
	const int totalFrames = 12; 
	if (frame > 3) {
		player.setTexture(moveDead[3]);
		frame++;
		return &player;
	}
	else {
		player.setTexture(moveDead[frame++]);
		return &player;
	}
}
Sprite* Character::forward(Character& enemy) {
	const int totalFrames = 4;
	if (frame == totalFrames) {
		frame = 0;
		return nullptr;
	}
	else {
		player.setTexture(moveForward[frame++]);
		if (x+60 < enemy.getX() && !getSide()) { player.setPosition(x += 10, y); }
		else if (x-50 > enemy.getX() && getSide())player.setPosition(x -= 10, y);
		return &player;
	}
}
Sprite* Character::backward(Character& enemy) {
	const int totalFrames = 4;
	if (frame == totalFrames) {
		frame = 0;
		return nullptr;
	}
	else {
		player.setTexture(moveBackward[frame++]);
		if(x>50&&!getSide())player.setPosition(x -= 10, y);
		else if (x < 600 && getSide())player.setPosition(x += 10, y);

		return &player;
	}
}

Sprite* Character::attack(Character& enemy) {
	const int totalFrames = 4;
	if (frame == totalFrames) {
		frame = 0;
		return nullptr;
	}
	else {
		player.setTexture(moveAttack[frame]);
		if (frame == 2) {
			int offset = !getSide() ? 60 : 80;
			if (player.getGlobalBounds().contains(enemy.getX() + offset, enemy.getY()))
				if (enemy.health > 0) { enemy.health -= attackVal - enemy.defense; enemy.damageGot = attackVal - enemy.defense; }
		}
		frame++;
		return &player;
	}
}

void Character::operator - (Character& C) {
	C.health -= attackVal;
}

void Character::loadCharacterAnimation(int i) {
	bool side = !getSide();
	string path;
	if (side) path = "assets/characters/"+ to_string(i) +"/";
	else path = "assets/characters/" + to_string(i) + "/back";
	moveAttack = new Texture[4];
	for (int i = 1;i <= 4;i++) {
		string temp = path + "Attack" + to_string(i) + ".png";
		cout << temp << endl;
		moveAttack[i - 1].loadFromFile(path + "Attack" + to_string(i) + ".png");
	}
	moveForward = new Texture[4];
	for (int i = 1;i <= 4;i++) moveForward[i - 1].loadFromFile(path+ "Walk" + to_string(i) + ".png");
	moveDead = new Texture[4];
	for (int i = 1;i <= 4;i++) moveDead[i - 1].loadFromFile(path+ "Dead" + to_string(i) + ".png");
	moveBackward = new Texture[4];
	for (int i = 1;i <= 4;i++) moveBackward[i - 1].loadFromFile(path + "back" + to_string(i) + ".png");
	moveIdle = new Texture;
	moveIdle->loadFromFile(path+"Idle1.png");
	player.setTexture(*moveIdle);
	if (side) { x = 150; y = 250; }
	else {x = 450; y=250;}
	player.setPosition(x, y);
}
void Character::reset() {
	health = 100;
	if (!side) { x = 150; y = 250; }
	else { x = 450; y = 250; }
	player.setPosition(x, y);
}

string Character::getStats() {
	string stats;
	stats = ("Attack: " + (to_string(attackVal).substr(0,4)) + "\nDefense: " + to_string(defense).substr(0,4) + "\nSAC Time: " + to_string(specialAbilityCoolDown)+" (s)");
	return stats;
}

void Character::setCoordinates(int X, int Y) { x = X; y = Y; }





