﻿#include<iostream>
#include <SFML/Graphics.hpp>
#include<string>
#include"GameManager.h"

using namespace std;
using namespace sf;

int main() {
    GameManager game;
    game.run();
    return 0;
}
