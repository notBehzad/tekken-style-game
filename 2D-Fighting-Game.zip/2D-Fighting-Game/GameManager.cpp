﻿#include<iostream>
#include<string>
#include<SFML/Graphics.hpp>
#include"GameManager.h"
#include<filesystem>
#include"Character.h"
#include"Arena.h"
#include<chrono>
#include<thread>
#include<fstream>
#include<ctime>

using namespace std;
using namespace sf;

bool GameManager::isButtonPressed(const Event& event, const Sprite& sprite) {
    if (event.type == Event::MouseButtonPressed && event.mouseButton.button == Mouse::Left) {
        FloatRect buttonBounds = sprite.getGlobalBounds();
        Vector2i mousePos = Mouse::getPosition(window);
        if (buttonBounds.contains((float)mousePos.x, (float)mousePos.y)) {
            currentState = SelectCharacters;
            return true;
        }
    }
    return false;
}

GameManager::GameManager() :window(VideoMode(800, 600), "Fantasy Game by Behzad", Style::Close) {
	loadAssets();
    currentState = 0;

	characterList[0] = new Berserk;
	characterList[1] = new Shaman;
	characterList[2] = new Warrior;
	characterList[3] = new Bob;
	characterList[4] = new DevilJin;

    player1 = player2 = -1;
    winner = -1;
}
void GameManager::loadAssets() {
    font.loadFromFile("assets\\gui\\Font\\CyberpunkCraftpixPixel.otf");
    textBackground.loadFromFile("assets/gui/textbg.png");
    Sprite textBg;
    textBg.setTexture(textBackground);
    textBg.setPosition(260, 130);
    textBg.setScale(0.6f, 0.6f);
    Text text;
    text.setString("Loading Assets...");
    text.setFont(font);
    text.setPosition(290, 265);
    text.setCharacterSize(22);
    window.draw(textBg);
    window.draw(text);
    window.display();


    arenaTexture[0].loadFromFile("assets/arena/PNG/summer/5.png");
    arenaTexture[1].loadFromFile("assets/arena/PNG/winter/5.png");
    arenaTexture[2].loadFromFile("assets/arena/PNG/spring/6.png");
    arenaTexture[3].loadFromFile("assets/arena/PNG/autumn/6.png");
}
void GameManager::run() {
	while (window.isOpen()) {
		Event event;
		while (window.pollEvent(event)) {
			if (event.type == sf::Event::Closed) window.close();
		}
		switch (currentState) {
		case Start: start(); break;
        case SelectCharacters: selectCharacters(); break;
        case SelectArena: selectArena(); break;
        case Fight: fight(); break;
        case Winner: displayWinner();break;
        case History: displayHistory();break;
        case Exit: exitGame(); break;
		}
		window.clear();
		window.display();
	}
}
void GameManager::start() {
    Texture backgroundTexture;
    Texture buttonTexture;
    Sprite backgroundSprite;
    Sprite buttonSprite;
    Text titleText, titleTextShadow, creator;

    backgroundTexture.loadFromFile("assets\\gui\\bg.png");
    float scaleX = window.getSize().x / (float)backgroundTexture.getSize().x;
    float scaleY = window.getSize().y / (float)backgroundTexture.getSize().y;
    backgroundSprite.setScale(scaleX, scaleY);
    backgroundSprite.setTexture(backgroundTexture);

    if (!buttonTexture.loadFromFile("assets\\gui\\start.png")) {
        std::cout << "Failed to load button image!" << std::endl;
    }
    else {
        std::cout << "Button image loaded successfully!" << std::endl;
    }
    buttonSprite.setTexture(buttonTexture);
    buttonSprite.setScale(0.05f, 0.05f);
    buttonSprite.setPosition(300, 400);


    titleTextShadow.setFont(font);
    titleTextShadow.setString("FANTASY GAME");
    titleTextShadow.setCharacterSize(61);
    titleTextShadow.setPosition(153, 223);
    titleTextShadow.setFillColor(Color::White);

    titleText.setFont(font);
    titleText.setString("FANTASY GAME");
    titleText.setCharacterSize(60);
    titleText.setPosition(160, 230);
    titleText.setFillColor(Color::Black);

    creator.setFont(font);
    creator.setString("By Behzad");
    creator.setCharacterSize(20);
    creator.setPosition(340, 300);
    creator.setFillColor(Color::Black);

    

    if (!buttonTexture.loadFromFile("assets\\gui\\start.png")) {
        std::cout << "Failed to load button image!" << std::endl;
    }
    else {
        std::cout << "Button image loaded successfully!" << std::endl;
    }
    buttonSprite.setTexture(buttonTexture);
    buttonSprite.setScale(0.05f, 0.05f);
    buttonSprite.setPosition(300, 400);

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
                return;
            }
            else if (isButtonPressed(event, buttonSprite)) return;
        }
        FloatRect buttonBounds = buttonSprite.getGlobalBounds();
        Vector2i mousePos = Mouse::getPosition(window);
        if (buttonBounds.contains((float)mousePos.x, (float)mousePos.y)) { buttonSprite.setScale(0.06f, 0.06f); buttonSprite.setPosition(280, 385);}
        else { buttonSprite.setScale(0.05f, 0.05f); buttonSprite.setPosition(300, 400); }
        window.clear(); 
        window.draw(backgroundSprite);
        window.draw(buttonSprite);
        window.draw(titleTextShadow); 
        window.draw(titleText); 
        window.draw(creator);

        window.display(); 
    }
}

void GameManager::selectCharacters() {
    bool selected = false;
    int selectedChar = -1;
    Texture backgroundTexture;
    backgroundTexture.loadFromFile("assets/gui/select.jpg");
    Sprite backgroundSprite;
    float scaleX = window.getSize().x / (float)backgroundTexture.getSize().x;
    float scaleY = window.getSize().y / (float)backgroundTexture.getSize().y;
    backgroundSprite.setScale(scaleX, scaleY);
    backgroundSprite.setTexture(backgroundTexture);

    for (int i = 0;i < 5;i++) characterList[i]->setDisplayPosition();

    Texture background;
    background.loadFromFile("assets/gui/textbg.png");

    Text selectCharactersShadow;
    selectCharactersShadow.setFont(font);
    selectCharactersShadow.setString("Select Your Character");
    selectCharactersShadow.setCharacterSize(41);
    selectCharactersShadow.setPosition(92, 65);
    selectCharactersShadow.setFillColor(Color::White);

    Text selectCharacters;
    selectCharacters.setString("Select Your Character");
    selectCharacters.setFont(font);
    selectCharacters.setCharacterSize(40);
    selectCharacters.setPosition(95, 70);
    selectCharacters.setFillColor(Color::Black);

    Text playerShadow;
    playerShadow.setFont(font);
    playerShadow.setCharacterSize(31);
    playerShadow.setPosition(328, 126);
    playerShadow.setFillColor(Color::White);

    Text player;
    player.setFont(font);
    player.setCharacterSize(30);
    player.setPosition(330, 130);
    player.setFillColor(Color::Black);



    /////////////players

    Text player1NameShadow;
    player1NameShadow.setString("Berserk");
    player1NameShadow.setFont(font);
    player1NameShadow.setCharacterSize(25.5);
    player1NameShadow.setPosition(78, 268);
    player1NameShadow.setFillColor(Color::White);

    Text player1Name;
    player1Name.setFont(font);
    player1Name.setString("Berserk");
    player1Name.setCharacterSize(25);
    player1Name.setPosition(80, 270);
    player1Name.setFillColor(Color::Black);

    Text player2NameShadow;
    player2NameShadow.setString("Shaman");
    player2NameShadow.setFont(font);
    player2NameShadow.setCharacterSize(25.5);
    player2NameShadow.setPosition(228, 268);
    player2NameShadow.setFillColor(Color::White);

    Text player2Name;
    player2Name.setFont(font);
    player2Name.setString("Shaman");
    player2Name.setCharacterSize(25);
    player2Name.setPosition(230, 270);
    player2Name.setFillColor(Color::Black);

    Text player3NameShadow;
    player3NameShadow.setString("Warrior");
    player3NameShadow.setFont(font);
    player3NameShadow.setCharacterSize(25.5);
    player3NameShadow.setPosition(358, 268);
    player3NameShadow.setFillColor(Color::White);

    Text player3Name;
    player3Name.setFont(font);
    player3Name.setString("Warrior");
    player3Name.setCharacterSize(25);
    player3Name.setPosition(360, 270);
    player3Name.setFillColor(Color::Black);

    Text player4NameShadow;
    player4NameShadow.setString("Bob");
    player4NameShadow.setFont(font);
    player4NameShadow.setCharacterSize(25.5);
    player4NameShadow.setPosition(508, 268);
    player4NameShadow.setFillColor(Color::White);

    Text player4Name;
    player4Name.setFont(font);
    player4Name.setString("Bob");
    player4Name.setCharacterSize(25);
    player4Name.setPosition(510, 270);
    player4Name.setFillColor(Color::Black);

    Text player5NameShadow;
    player5NameShadow.setString("Devil Jin");
    player5NameShadow.setFont(font);
    player5NameShadow.setCharacterSize(25.5);
    player5NameShadow.setPosition(598, 268);
    player5NameShadow.setFillColor(Color::White);

    Text player5Name;
    player5Name.setFont(font);
    player5Name.setString("Devil Jin");
    player5Name.setCharacterSize(25);
    player5Name.setPosition(600, 270);
    player5Name.setFillColor(Color::Black);


    while (window.isOpen()) {
        Event event;
        if (!selected) playerShadow.setString("Player 1");
        else playerShadow.setString("Player 2");

        if (!selected) player.setString("Player 1");
        else player.setString("Player 2");

        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                return; 
            }
            else for (int i = 0;i < 5;i++) if (isButtonPressed(event, characterList[i]->player)) {
                Sprite textBg;
                textBg.setTexture(background);
                textBg.setPosition(260, 170);
                textBg.setScale(0.6f, 0.6f);

                Text text;
                text.setString(characterList[i]->getName() + " Selected!");
                text.setFont(font);
                text.setPosition(290, 305);
                text.setCharacterSize(22);
                if (player1 == i) {
                    text.setString("Already selected\n   by Player 1!");
                    text.setPosition(290, 290);
                    window.draw(textBg);
                    window.draw(text);
                    window.display();
                    this_thread::sleep_for(chrono::milliseconds(2000));
                    continue;
                }
                else {
                    window.draw(textBg);
                    window.draw(text);
                    window.display();
                    this_thread::sleep_for(chrono::milliseconds(2000));   //using sleep from windows was causing byte ambiguity
                    if (!selected) {
                        P1 = characterList[i];
                        P1->setSide(selected);
                        selected = true;
                        player1 = i;
                    }
                    else { P2 = characterList[i]; P2->setSide(selected); currentState = SelectArena; player2 = i; return; }
                }
               
            }
        }
        Sprite textBg;
        Text stats;
        bool hover = false;
        for (int i = 0;i < 5;i++) {
            FloatRect bounds = characterList[i]->player.getGlobalBounds();
            Vector2i mousePos = Mouse::getPosition(window);
            if (i < 3) {
                if (bounds.contains((float)mousePos.x, (float)mousePos.y)) {
                    characterList[i]->player.setScale(1.6f, 1.6f);

                    textBg.setTexture(background);
                    textBg.setPosition(mousePos.x, mousePos.y-50);
                    textBg.setScale(0.4f, 0.6f);

                    stats.setString(characterList[i]->getStats());
                    stats.setFont(font);
                    stats.setCharacterSize(18);
                    stats.setPosition(mousePos.x+20, mousePos.y+65);
                    hover = true;
                }
                else characterList[i]->player.setScale(1.5f, 1.5f);
                

                
            }
            else {
                if (bounds.contains((float)mousePos.x, (float)mousePos.y)) {
                    characterList[i]->player.setScale(1.9f, 1.9f);
                    textBg.setTexture(background);
                    textBg.setPosition(mousePos.x, mousePos.y - 50);
                    textBg.setScale(0.4f, 0.6f);

                    stats.setString(characterList[i]->getStats());
                    stats.setFont(font);
                    stats.setCharacterSize(18);
                    stats.setPosition(mousePos.x + 20, mousePos.y + 70);
                    hover = true;
                }
                else characterList[i]->player.setScale(1.8f, 1.8f);
            }
        }
        window.clear();

        window.draw(backgroundSprite);
        window.draw(selectCharactersShadow);
        window.draw(selectCharacters);
        window.draw(playerShadow);
        window.draw(player);

        for (int i = 0;i < 5;i++) window.draw(characterList[i]->player);

        window.draw(player1NameShadow);
        window.draw(player2NameShadow);
        window.draw(player3NameShadow);
        window.draw(player4NameShadow);
        window.draw(player5NameShadow);

        window.draw(player1Name);
        window.draw(player2Name);
        window.draw(player3Name);
        window.draw(player4Name);
        window.draw(player5Name);

        if (hover) {
            hover = false;
            window.draw(textBg);
            window.draw(stats);
        }

        window.display();
    }
}
void GameManager::selectArena(){
    string arenaNames[4] = { "Summer","Winter","Spring","Autumn" };

    Texture backgroundTexture;
    backgroundTexture.loadFromFile("assets/gui/arenabg.jpg");
    Sprite backgroundSprite;
    float scaleX = window.getSize().x / (float)backgroundTexture.getSize().x;
    float scaleY = window.getSize().y / (float)backgroundTexture.getSize().y;
    backgroundSprite.setTexture(backgroundTexture);
    backgroundSprite.setScale(scaleX, scaleY);


    Text selectArenaShadow;
    selectArenaShadow.setFont(font);
    selectArenaShadow.setString("Select Arena");
    selectArenaShadow.setCharacterSize(41);
    selectArenaShadow.setPosition(247, 65);
    selectArenaShadow.setFillColor(Color::White);

    Text selectArena;
    selectArena.setString("Select Arena");
    selectArena.setFont(font);
    selectArena.setCharacterSize(40);
    selectArena.setPosition(250, 70);
    selectArena.setFillColor(Color::Black);

    ///////////arena pics

    Sprite arenaList[4];

    for (int i = 0;i < 4;i++) {
        arenaList[i].setTexture(arenaTexture[i]);
        arenaList[i].setScale(0.3f, 0.3f);
    }


    Text arenaName[4], arenaNameShadow[4];

    for (int i = 0;i < 4;i++) {
        arenaNameShadow[i].setString(arenaNames[i]);
        arenaNameShadow[i].setFont(font);
        arenaNameShadow[i].setCharacterSize(30);
        arenaNameShadow[i].setFillColor(Color::White);

        arenaName[i].setFont(font);
        arenaName[i].setString(arenaNames[i]);
        arenaName[i].setCharacterSize(29);
        arenaName[i].setFillColor(Color::Black);
    }

   
    arenaNameShadow[0].setPosition(148, 148);
    arenaName[0].setPosition(150, 150);

    arenaNameShadow[1].setPosition(508, 148);
    arenaName[1].setPosition(510, 150);

    arenaNameShadow[2].setPosition(158, 348);
    arenaName[2].setPosition(160, 350);

    arenaNameShadow[3].setPosition(498, 348);
    arenaName[3].setPosition(500, 350);


    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
                return;
            }
            else for (int i = 0;i < 4;i++) if (isButtonPressed(event, arenaList[i])) {
                Sprite textBg;
                textBg.setTexture(textBackground);
                textBg.setPosition(260, 170);
                textBg.setScale(0.6f, 0.6f);
                arena = new Arena(i, P1, P2, arenaTexture[i], arenaList[i]);
                Text text;
                text.setString(arena->getName() + " Selected!");
                text.setFont(font);
                text.setPosition(290, 305);
                text.setCharacterSize(22);
                window.draw(textBg);
                window.draw(text);
                window.display();
                this_thread::sleep_for(chrono::milliseconds(1000));   //using sleep from windows was causing byte ambiguity
                currentState = Fight;
                return;
            }
        }
        arenaList[0].setPosition(100, 200);
        arenaList[1].setPosition(450, 200);
        arenaList[2].setPosition(100, 400);
        arenaList[3].setPosition(450, 400);
        for (int i = 0;i < 4;i++) {
            FloatRect bounds = arenaList[i].getGlobalBounds();
            Vector2i mousePos = Mouse::getPosition(window);
            if (bounds.contains((float)mousePos.x, (float)mousePos.y)) {
                arenaList[i].setScale(0.065f, 0.065f);

                if(i==0) arenaList[0].setPosition(94, 194);
                else if(i==1) arenaList[1].setPosition(444, 194);
                else if(i==2) arenaList[2].setPosition(94, 394);
                else if(i==3) arenaList[3].setPosition(444, 394);
                //Text buff;
                //buff.setFont(font);
                //stats.setString(characterList[i]->getStats());
            }
            else arenaList[i].setScale(0.06f, 0.06f);
                
        }
        window.clear();
        window.draw(backgroundSprite);
        window.draw(selectArenaShadow);
        window.draw(selectArena);

        for (int i = 0;i < 4;i++) { window.draw(arenaList[i]); window.draw(arenaNameShadow[i]); window.draw(arenaName[i]);}

        window.display();
    }
}
void GameManager::fight() {
    int round=1;
    int player1wins = 0, player2wins = 0;
    bool isIdle1 = true, isIdle2=true;
    int secondsP1 = 0, secondsP2 = 0;
    int coolDownSecP1 = 0, coolDownSecP2 = 0;
    bool isAbilityActiveP1 = false;
    bool isAbilityActiveP2 = false;
    bool abilityReadyP1 = false, abilityReadyP2 = false;

    window.clear();
    Sprite textBg;
    textBg.setTexture(textBackground);
    textBg.setPosition(260, 130);
    textBg.setScale(0.6f, 0.6f);
    Text text;
    text.setString("Loading Assets...");
    text.setFont(font);
    text.setPosition(290, 265);
    text.setCharacterSize(22);
    window.draw(textBg);
    window.draw(text);
    window.display();
    Sprite* out1 = NULL, * out2 = NULL;
    bool won = false;

    arena->getSprite().setPosition(0, 0);

    P1->loadCharacterAnimation(player1);
    P2->loadCharacterAnimation(player2);

    Text player1NameShadow;
    player1NameShadow.setString(P1->getName());
    player1NameShadow.setFont(font);
    player1NameShadow.setCharacterSize(30);
    player1NameShadow.setPosition(33, 88);
    player1NameShadow.setFillColor(Color::White);

    Text player1Name;
    player1Name.setFont(font);
    player1Name.setString(P1->getName());
    player1Name.setCharacterSize(30);
    player1Name.setPosition(35, 90);
    player1Name.setFillColor(Color::Black);

    Text player2NameShadow;
    player2NameShadow.setString(P2->getName());
    player2NameShadow.setFont(font);
    player2NameShadow.setCharacterSize(30);
    FloatRect marginNameShadow = player2NameShadow.getLocalBounds();
    player2NameShadow.setOrigin(marginNameShadow.width, 0);
    player2NameShadow.setPosition(763, 88);
    player2NameShadow.setFillColor(Color::White);

    Text player2Name;
    player2Name.setFont(font);
    player2Name.setString(P2->getName());
    player2Name.setCharacterSize(30);
    FloatRect marginName = player2Name.getLocalBounds();
    player2Name.setOrigin(marginName.width, 0);
    player2Name.setPosition(765, 90);
    player2Name.setFillColor(Color::Black);

    P1->currentMove = &Character::idle;
    P2->currentMove = &Character::idle;

    Texture shadowTexture;
    shadowTexture.loadFromFile("assets\\gui\\playerShadow.png");
    Sprite shadow1;
    shadow1.setScale(0.2f, 0.2f);
    shadow1.setTexture(shadowTexture);
    Sprite shadow2;
    shadow2.setScale(0.2f, 0.2f);
    shadow2.setTexture(shadowTexture);

    if (player2 < 3) P2->player.setScale(1.5f, 1.5f);
    else P2->player.setScale(1.8f, 1.8f);

    out1 = (P1->*P1->currentMove)(*P2);
    out2 = (P2->*P2->currentMove)(*P1);

    float damageVal1 = 0;
    Text damage1;
    damage1.setFont(font);
    int count1 = -1;
    damage1.setFillColor(Color::Red);

    float damageVal2 = 0;
    Text damage2;
    damage2.setFont(font);
    int count2 = -1;
    damage2.setFillColor(Color::Red);

    RectangleShape health1bg(Vector2f(300.0f, 40.0f));
    health1bg.setFillColor(Color(50, 50, 50));
    health1bg.setPosition(30, 30);

    RectangleShape health1(Vector2f(290.0f, 30.0f));
    health1.setFillColor(Color(0,191,0));
    health1.setPosition(35, 35);

    RectangleShape health1shade(Vector2f(290.0f, 10.0f));
    health1shade.setFillColor(Color(255,255,255,128));
    health1shade.setPosition(35, 35);

    RectangleShape health2bg(Vector2f(300.0f, 40.0f));
    health2bg.setFillColor(Color(50, 50, 50));
    health2bg.setPosition(460, 30);

    RectangleShape health2(Vector2f(290.0f, 30.0f));
    health2.setFillColor(Color(0, 191, 0));
    health2.setPosition(465, 35);

    RectangleShape health2shade(Vector2f(290.0f, 10.0f));
    health2shade.setFillColor(Color(255, 255, 255, 128));
    health2shade.setPosition(465, 35);

    Text matchStats;
    matchStats.setString(to_string(player1wins) + " : " + to_string(player2wins));
    matchStats.setFont(font);
    matchStats.setCharacterSize(40);
    matchStats.setPosition(342, 25);

    Text roundDisplay;
    roundDisplay.setString("Round " + to_string(round));
    roundDisplay.setFont(font);
    roundDisplay.setCharacterSize(40);
    roundDisplay.setPosition(300, 100);

    Text abilityStateP1;
    abilityStateP1.setFont(font);
    abilityStateP1.setCharacterSize(25);
    abilityStateP1.setPosition(50, 500);

    Text abilityStateP2;
    abilityStateP2.setFont(font);
    abilityStateP2.setCharacterSize(25);
    abilityStateP2.setPosition(550, 500);

    Text abilityIsReadyP1;
    abilityIsReadyP1.setFont(font);
    abilityIsReadyP1.setCharacterSize(25);
    abilityIsReadyP1.setPosition(50, 530);

    Text abilityIsReadyP2;
    abilityIsReadyP2.setFont(font);
    abilityIsReadyP2.setCharacterSize(25);
    abilityIsReadyP2.setPosition(550, 530);

    int P1frames = 10, P2frames = 10;

    float frameDuration = 0.1f;
    Clock durationCheck;
    int frameCount = 0;
    while (window.isOpen()) {
        Event event;
        window.clear();
        window.draw(arena->getSprite());

        while (window.pollEvent(event)) {
            if (event.type == Event::Closed) {
                window.close();
                return;
            }
            else {
                if (isIdle1) {
                    if (Keyboard::isKeyPressed(Keyboard::D)) {
                        P1->currentMove = &Character::forward;isIdle1 = true; 
                    }
                    else if (Keyboard::isKeyPressed(Keyboard::A)) {
                        P1->currentMove = &Character::backward;isIdle1 = true;
                    }
                    else if (Keyboard::isKeyPressed(Keyboard::E)) {
                        P1->currentMove = &Character::attack; isIdle1 = false;  P1->resetFrame();
                    }
                    else if (Keyboard::isKeyPressed(Keyboard::Q)&&abilityReadyP1) {
                        isAbilityActiveP1 = true;
                        cout << "Ability Activated";
                        abilityStateP1.setString("Ability Activated");
                        P1->useSpecialAbility(*P2);
                        P1frames = 0;

                    }
                    else {
                        P1->currentMove = &Character::idle;
                    }
                }
                if (isIdle2) {
                    if (Keyboard::isKeyPressed(Keyboard::J)) {
                        P2->currentMove = &Character::forward; isIdle2 = true;
                    }
                    else if (Keyboard::isKeyPressed(Keyboard::L)) {
                        P2->currentMove = &Character::backward; isIdle2 = true; 
                    }
                    else if (Keyboard::isKeyPressed(Keyboard::U)) {
                        P2->currentMove = &Character::attack; isIdle2 = false; P2->resetFrame();
                    }
                    else if (Keyboard::isKeyPressed(Keyboard::O) && abilityReadyP2) {
                        isAbilityActiveP2 = true;
                        cout << "Ability Activated";
                        abilityStateP2.setString("Ability Activated");
                        P2->useSpecialAbility(*P1);
                        P2frames = 0;

                    }
                    else {
                        P2->currentMove = &Character::idle;
                    }
                }
            }
        }
        if (P1->getHealth() <= 0&&!won) {
            P1->currentMove = &Character::dead;
            P1->resetFrame();
            player2wins++;
            isIdle1 = false;
            won = true;
            text.setString("Player 2 Won!!!");

        }
        else if (P2->getHealth() <= 0&&!won) {
            P2->currentMove = &Character::dead;
            P2->resetFrame();
            isIdle2 = false;
            player1wins++;
            won = true;
            text.setString("Player 1 Won!!!");

        }
        if (frameCount == 12) {
            frameCount = 0;
            P1->resetFrame();
            P2->resetFrame();
            won = false;
            round++;
            roundDisplay.setString("Round " + to_string(round));
            matchStats.setString(to_string(player1wins) + " : " + to_string(player2wins));
            P1->reset();
            P2->reset();
            
            health1.setFillColor(Color(0, 191, 0));
            health2.setFillColor(Color(0, 191, 0));


            window.draw(textBg);
            window.draw(text);
            window.display();
            this_thread::sleep_for(chrono::milliseconds(2000));
            isIdle1 = true;
            isIdle2 = true;
            P1->currentMove = &Character::idle;
            out1 = (P1->*P1->currentMove)(*P2);
            P2->currentMove = &Character::idle;
            out2 = (P2->*P2->currentMove)(*P1);

            if (round == 4) {
                if (player1wins > player2wins) winner = 1;
                else winner = 2;
                logGame(player1wins, player2wins);
                currentState = Winner;
                return;
            }

        }
        
        if (durationCheck.getElapsedTime().asSeconds() >= frameDuration) {
            if (won) frameCount++;
            if (P1frames < 10) P1frames++;
            if (P2frames < 10) P2frames++;
            if (isAbilityActiveP1) {
                abilityReadyP1 = false;
                secondsP1++;
                if (secondsP1 > P1->specialAbilityDuration*10) {
                    P1->setValuesFromConfig();
                    secondsP1 = 0;
                    isAbilityActiveP1 = false;
                    P2->freeze = false;
                    cout << "Ability ended";
                    abilityStateP1.setString("Ability Ended");
                    P1frames = 0;
                }
            }
            else if(!abilityReadyP1) {
                coolDownSecP1++;
                if (coolDownSecP1 > P1->specialAbilityCoolDown * 10) {
                    coolDownSecP1 = 0;
                    abilityReadyP1 = true;
                    cout << "Ability Ready";
                    abilityIsReadyP1.setString("Ability Ready");
                }
            }
            if (isAbilityActiveP2) {
                secondsP2++;
                abilityReadyP2 = false;
                if (secondsP2 > P2->specialAbilityDuration * 10) {
                    P2->setValuesFromConfig();
                    secondsP2 = 0;
                    isAbilityActiveP2 = false;
                    P1->freeze = false;
                    cout << "Ability Ended";
                    abilityStateP2.setString("Ability Ended");
                    P2frames = 0;

                }
            }
            else if (!abilityReadyP2) {
                coolDownSecP2++;
                if (coolDownSecP2 > P2->specialAbilityCoolDown * 10) {
                    cout << "Ability Ready";
                    abilityIsReadyP2.setString("Ability Ready");

                    abilityReadyP2 = true;
                    coolDownSecP2 = 0;
                }
            }
            out1 = (P1->*P1->currentMove)(*P2);
            out2 = (P2->*P2->currentMove)(*P1);
            if (out1 == NULL) {
                if (Keyboard::isKeyPressed(Keyboard::D)) {
                    P1->currentMove = &Character::forward; isIdle1 = true;
                }
                else if (Keyboard::isKeyPressed(Keyboard::A)) {
                    P1->currentMove = &Character::backward; isIdle1 = true;
                }
                else if (Keyboard::isKeyPressed(Keyboard::E)) {
                    P1->currentMove = &Character::attack; isIdle1 = false;
                }
                else if (Keyboard::isKeyPressed(Keyboard::Q) && abilityReadyP1) {
                    isAbilityActiveP1 = true;
                    cout << "Ability Activated";
                    abilityStateP1.setString("Ability Activated");

                    P1->useSpecialAbility(*P2);
                    P1frames = 0;

                }
                else{
                    P1->currentMove = &Character::idle;
                    isIdle1 = true;
                }
                out1 = (P1->*P1->currentMove)(*P2);
            }
            if (out2 == NULL) {
                if (Keyboard::isKeyPressed(Keyboard::J)) {
                    P2->currentMove = &Character::forward; isIdle2 = true;
                }
                else if (Keyboard::isKeyPressed(Keyboard::L)) {
                    P2->currentMove = &Character::backward; isIdle2 = true;
                }
                else if (Keyboard::isKeyPressed(Keyboard::U)) {
                    P2->currentMove = &Character::attack; isIdle2 = false;
                }
                else if (Keyboard::isKeyPressed(Keyboard::O) && abilityReadyP2) {
                    isAbilityActiveP2 = true;
                    cout << "Ability Activated";
                    abilityStateP2.setString("Ability Activated");

                    P2->useSpecialAbility(*P1);
                    P2frames = 0;

                }
                else{
                    P2->currentMove = &Character::idle;
                    isIdle2 = true;
                }
                out2 = (P2->*P2->currentMove)(*P1);
            }
            if (P1->damageGot>0) { count1 = 6; damage1.setString("-" + to_string(P1->damageGot).substr(0, 3));  P1->damageGot = 0; }
            if (count1 >= 0) count1--;
            if (P2->damageGot>0) { count2 = 6; damage2.setString("-" + to_string(P2->damageGot).substr(0, 3)); P2->damageGot = 0; }
            if (count2 >= 0) count2--;

            if (P1->health < 0) P1->health = 0;
            if (P1->health < 30) health1.setFillColor(Color(255, 0, 0, 200));
            else if (P1->health < 60) health1.setFillColor(Color(255, 165, 0, 200));
            else if (P1->health < 80) health1.setFillColor(Color(255, 255, 0, 200));
            health1.setSize(Vector2f(((P1->getHealth() / 100) * 290), 30));
            health1shade.setSize(Vector2f(((P1->getHealth() / 100) * 290), 10));

            if (P2->health < 0) P2->health = 0;
            if (P2->health < 30) health2.setFillColor(Color(255, 0, 0, 200));
            else if (P2->health < 60) health2.setFillColor(Color(255, 165, 0, 200));
            else if (P2->health < 80) health2.setFillColor(Color(255, 255, 0, 200));
            health2.setSize(Vector2f(((P2->getHealth() / 100) * 290), 30));
            health2shade.setSize(Vector2f(((P2->getHealth() / 100) * 290), 10));

            durationCheck.restart();
        }
        if (count1 % 2 == 0) {
            damage1.setPosition(P1->getX()+35, 250);
            window.draw(damage1);
        }
        if (count2 % 2 == 0) {
            damage2.setPosition(P2->getX()+45, 250);
            window.draw(damage2);
        }
        if (!out1) std::cout << "out1 is NULL\n";
        if (!out2) std::cout << "out2 is NULL\n";
        shadow1.setPosition(P1->getX()+25, 380);
        shadow2.setPosition(P2->getX()+25, 380);           ///check the shadows
        
        window.draw(health1bg);
        window.draw(health1);
        window.draw(health1shade);

        window.draw(matchStats);
        window.draw(roundDisplay);

        window.draw(player1NameShadow);
        window.draw(player1Name);

        window.draw(player2NameShadow);
        window.draw(player2Name);

        window.draw(health2bg);
        window.draw(health2);
        window.draw(health2shade);

        if (abilityReadyP1) window.draw(abilityIsReadyP1);
        if (P1frames<10) window.draw(abilityStateP1);

        if (abilityReadyP2) window.draw(abilityIsReadyP2);
        if (P2frames < 10) window.draw(abilityStateP2);

        window.draw(shadow1);
        window.draw(shadow2);
        window.draw(*out1);
        window.draw(*out2);
        window.display();
    }
}
void GameManager::displayWinner() {
    Texture backgroundTexture;
    backgroundTexture.loadFromFile("assets/gui/winner.png");
    Sprite backgroundSprite;
    float scaleX = window.getSize().x / (float)backgroundTexture.getSize().x;
    float scaleY = window.getSize().y / (float)backgroundTexture.getSize().y;
    backgroundSprite.setScale(scaleX, scaleY);
    backgroundSprite.setTexture(backgroundTexture);
    Texture trophyTexture;
    trophyTexture.loadFromFile("assets/gui/trophy.png");
    Sprite trophy(trophyTexture);
    trophy.setPosition(200, 240);
    trophy.setScale(0.7f, 0.7f);
    Text declare[3];
    for (int i = 0;i < 3;i++) {
        declare[i].setString("PLAYER " + to_string(winner) + " IS THE CHAMPION!!!");
        declare[i].setFont(font);
        declare[i].setCharacterSize(40);
    }
    declare[0].setPosition(100, 120);
    declare[0].setFillColor(Color(255, 215, 0));
    declare[1].setPosition(95, 115);
    declare[1].setFillColor(Color::Black);
    declare[2].setPosition(93, 118);
    declare[2].setFillColor(Color::White);

    Sprite Bg[3];
    Text text[3];

    for (int i = 0;i < 3;i++) {
        Bg[i].setTexture(textBackground);
        text[i].setFont(font);
        text[i].setCharacterSize(22);

    }

    Bg[0].setPosition(490, 490);
    Bg[0].setScale(0.3f, 0.3f);
    text[0].setString("RESTART");
    text[0].setPosition(510, 550);

    Bg[1].setPosition(645, 490);
    Bg[1].setScale(0.3f, 0.3f);
    text[1].setString("HISTORY");
    text[1].setPosition(665, 550);

    Bg[2].setTexture(textBackground);
    Bg[2].setPosition(15, 490);
    Bg[2].setScale(0.25f, 0.3f);
    text[2].setString("EXIT");
    text[2].setPosition(50, 550);

    while (window.isOpen()) {
        Event event;
        while (window.pollEvent(event)) {
            if (event.type == sf::Event::Closed) {
                window.close();
                return;
            }
            else {
                for (int i = 0;i < 3;i++) if (isButtonPressed(event, Bg[i])) {
                    if (i == 0) currentState = SelectCharacters;
                    else if (i == 1) currentState = History;
                    else currentState = Exit;
                    return;
                }
            }
        }
        window.clear();
        window.draw(backgroundSprite);
        window.draw(trophy);
        for (int i = 2; i >= 0; i--) { window.draw(declare[i]); window.draw(Bg[i]); window.draw(text[i]); }
        window.display();
    }
}
void GameManager::displayHistory() {
    ifstream history("logFile.txt");
    if (!history.is_open()) {
        cout << "Failed to open logFile.txt" << endl;
        return;
    }
    string output;
    while (getline(history,output)) {
        cout << output << endl;
    }
    history.close();
    currentState = SelectCharacters;
}
void GameManager::logGame(int wins1, int wins2) {
    ofstream historyLog("logFile.txt", ios::app);
    historyLog << getDetails() +" \tPlayer 1 wins: " + to_string(wins1) + " ,Player 2 wins: " + to_string(wins2)+'\n';
    historyLog.close();
}
string GameManager::getDetails() {
    time_t now = time(0);
    tm time;
    localtime_s(&time, &now);
    string readable = to_string(time.tm_hour) + ":" + to_string(time.tm_min) + ":" + to_string(time.tm_sec) + " " + to_string(time.tm_mday) + "/" + to_string(time.tm_mon+1) + "/" + to_string(time.tm_year+1900);
    return readable + " \tPlayer 1: " + P1->getName() + " ,Player 2: " + P2->getName() + " \tWinner: Player " + to_string(winner);
}
void GameManager::exitGame() {
    window.close();
}