#pragma once
#include <string>
#include <iostream>
#include <SFML/Graphics.hpp>

using namespace std;
using namespace sf;

class Character {
	friend class GameManager;
protected:
	string name;
	bool side;
	int level, frame;
	float health, attackVal, defense;
	Texture texture;
	Texture* moveAttack;
	Texture* moveForward;
	Texture* moveIdle;
	Texture* moveDead;
	Texture* moveBackward;
	Sprite player;
	int x, y;
public:
	Character(string);
	int specialAbilityCoolDown, specialAbilityDuration;
	float damageGot;
	bool freeze;
	virtual void attackTarget(Character&) = NULL;
	virtual void useSpecialAbility(Character& enemy) = NULL;
	virtual void setDisplayPosition() = NULL;
	Texture& getTexture();
	Sprite& getSprite();
	string getName();
	float& getHealth();
	void setSide(bool);
	bool getSide();
	int getX();
	int getY();
	void resetFrame();
	void setValuesFromConfig();
	float getDefense();
	//string getStats();
	//float operator + (const Character& C); //combine two character's attack
	//bool operator == (const Character& C); //compare health
	void operator - (Character& C); //attack
	//Character& operator << (ostream& out); //character stats
	Sprite* idle(Character&);
	Sprite* forward(Character&);
	Sprite* backward(Character&);
	Sprite* attack(Character&);
	Sprite* dead(Character&);
	void loadCharacterAnimation(int i);
	Sprite* (Character::*currentMove)(Character& enemy);
	void reset();
	string getStats();
	void setCoordinates(int, int);
};
class Berserk : public Character {
public:
	Berserk();
	void attackTarget(Character&) override;
	void useSpecialAbility(Character& enemy) override;
	void setDisplayPosition() override;
};
class Shaman : public Character {
public:
	Shaman();
	void attackTarget(Character&) override;
	void useSpecialAbility(Character& enemy) override;
	void setDisplayPosition() override;

};
class Warrior: public Character {
public:
	Warrior();
	void attackTarget(Character&) override;
	void useSpecialAbility(Character& enemy) override;
	void setDisplayPosition() override;

};
class Bob : public Character {
public:
	Bob();
	void attackTarget(Character&) override;
	void useSpecialAbility(Character& enemy) override;
	void setDisplayPosition() override;

};
class DevilJin : public Character {
public:
	DevilJin();
	void attackTarget(Character&) override;
	void useSpecialAbility(Character& enemy) override;
	void setDisplayPosition() override;

};
