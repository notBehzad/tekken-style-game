
#pragma once
#include "Arena.h"
#include<SFML/Graphics.hpp>
#include"Character.h"
using namespace sf;
class GameManager {
	Arena *arena;
	Character *characterList[5];
	Character *P1, *P2;
	RenderWindow window;
	Font font;
	bool isButtonPressed(const Event& event, const Sprite& sprite);
	enum state {Start, SelectCharacters, SelectArena, Fight, Winner, History, Exit};
	int currentState;
	Texture arenaTexture[4];
	Texture textBackground;
	int player1, player2;
	int winner;
public:
	GameManager();
	void run();
	void start();
	void loadAssets();
	void selectCharacters();
	void selectArena();
	void fight();
	void displayWinner();
	void displayHistory();
	void exitGame();
	void logGame(int, int);
	string getDetails();
	/*void matchup();
	void displayResults();
	void saveBattleHistory();
	void displayBattleHistory();*/
};

