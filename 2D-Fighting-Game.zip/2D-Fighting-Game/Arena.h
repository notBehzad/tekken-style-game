#pragma once
#include <string>
#include "Character.h"

using namespace std;

enum Type{SUMMER,WINTER,SPRING,AUTUMN};
class Arena {
	string name;
	Type type;
	Character *P1, *P2;
	Texture texture;
	Sprite sprite;
public:
	Arena(int t, Character*& p1, Character*& p2, Texture tex, Sprite spr);
	Texture& getTexture();
	Sprite& getSprite();
	string getName();
	void setType(int);
};
