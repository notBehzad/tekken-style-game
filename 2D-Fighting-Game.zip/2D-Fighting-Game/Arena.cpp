#include<iostream>
#include<string>
#include"Arena.h"
#include<SFML/Graphics.hpp>
#include"Character.h"

using namespace std;
using namespace sf;

string Arena::getName() { return name; }
Texture& Arena::getTexture() { return texture; }
Sprite& Arena::getSprite() { return sprite; }
void Arena::setType(int t) { type = static_cast<Type>(t); }
Arena::Arena(int t, Character*& p1, Character*& p2, Texture tex, Sprite spr){
	type = static_cast<Type>(t);
	if (type == SUMMER) name = "Summer";
	else if (type == WINTER) name = "Winter";
	else if (type == SPRING) name = "Spring";
	else if (type == AUTUMN) name = "Autumn";
	P1 = p1;
	P2 = p2;
	texture = tex;
	sprite = spr;
	float scaleX = 800 / (float)texture.getSize().x;
	float scaleY = 600 / (float)texture.getSize().y;
	sprite.setScale(scaleX, scaleY);
	sprite.setTexture(texture);
}

